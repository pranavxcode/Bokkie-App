Please use the following template to submit your issue. Following this template will allow us to quickly investigate and help you with your issue. Please be aware that issues which do not conform to this template may be closed.

For feature requests please contact us at team@intercom.io


## Version info
  - Intercom for iOS version:
  - iOS version:

## Expected behavior

## Actual behavior

## Steps to reproduce
 1. 
 2. 
 3. 

## Logs