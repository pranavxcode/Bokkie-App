//
//  main.m
//  Sample
//
//  Created by James Treanor on 13/05/2015.
//  Copyright (c) 2015 Intercom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITCAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ITCAppDelegate class]));
    }
}
